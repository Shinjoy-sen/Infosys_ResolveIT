const { createApp, ref, reactive, onMounted } = Vue;
const SHEET_CSV_URL =
  "https://docs.google.com/spreadsheets/d/1huO7VGuZh63aIdOKRlJaae7dkAHJrxKGWaCNTnBCP1U/export?format=csv&gid=0";

async function loadCategoriesMap() {
  try {
    const res = await fetch(SHEET_CSV_URL, { cache: "no-store" });
    if (!res.ok) throw new Error("sheet not ok: " + res.status);
    const text = await res.text();
    if (text.trim().startsWith("<")) throw new Error("html instead of csv");
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const map = {};
    for (const line of lines) {
      const parts = line.split(",");
      const cat = parts[0].trim();
      if (!cat || cat.toLowerCase() === "category") continue;
      const subs = parts.slice(1).map((s) => s.trim()).filter(Boolean);
      map[cat] = subs.length ? subs : ["General"];
    }
    return Object.keys(map).length
      ? map
      : { Infrastructure: ["Roads", "Water"], "Public Safety": ["Theft", "Assault"] };
  } catch (e) {
    console.warn("categories load failed", e);
    return {
      Infrastructure: ["Roads", "Water"],
      "Public Safety": ["Theft", "Assault"],
      Services: ["Garbage", "Transport"],
    };
  }
}

async function login(credentials) {
  const res = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(credentials),
  });

  // Read response as text (safe for both JSON + plain text)
  const text = await res.text();

  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = text; // fallback if not json
  }

  // Handle errors
  if (!res.ok) {
    const msg =
      (data && data.error) ||
      (typeof data === "string" ? data : "Login failed");
    throw new Error(msg);
  }

  // Success
  if (data.token) localStorage.setItem("token", data.token);
  return data;
}

async function registerUser(credentials) {
  const res = await fetch("/api/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(credentials),
  });

  // Read response ONCE safely
  const text = await res.text();

  // Try parsing JSON only once if needed
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = text;
  }

  if (!res.ok) {
    throw new Error(
      typeof data === "string" && data.trim() !== "" ? data : "Registration failed"
    );
  }
  return data;
}


/*
async function register(event) {
  event.preventDefault();

  const username = document.getElementById("username")?.value.trim();
  const email = document.getElementById("email")?.value.trim();
  const password = document.getElementById("password")?.value.trim();

  // stop here if fields are empty
  if (!username || !password) {
    alert("Please fill all required fields!");
    return; // <-- critical: stops the function
  }

  try {
    const response = await fetch("http://localhost:8090/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password }),
    });

    if (response.ok) {
      alert("Registration successful — please login.");
    } else {
      const err = await response.json().catch(() => ({}));
      alert("Register failed: " + (err.error || response.statusText));
    }
  } catch (e) {
    alert("Error: " + e.message);
  }
}
*/



async function anonymous() {
  const res = await fetch("/api/auth/anonymous", { method: "POST" });
  const data = await res.json();
  if (!res.ok) throw new Error(data || "Anon failed");
  if (data.token) localStorage.setItem("token", data.token);
  return data;
}

async function submitComplaint(form) {
  const token = localStorage.getItem("token");
  const fd = new FormData();
  Object.entries(form).forEach(([k, v]) => {
    if (k === "files") return;
    fd.append(k, v || "");
  });
  for (const f of form.files || []) fd.append("files", f);

  const res = await fetch("/api/complaints", {
    method: "POST",
    headers: token ? { Authorization: "Bearer " + token } : {},
    body: fd,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data || "Submit failed");
  return data;
}

const App = {
  setup() {
    const view = ref(window.location.hash.replace("#", "") || "register");
    const categories = ref({});
    const subcategories = ref([]);
    const form = reactive({
      name: "",
      email: "",
      category: "",
      subcategory: "",
      location: "",
      dateOfIncident: "",
      description: "",
      urgency: "LOW",
      files: [],
    });
    const myComplaints = ref([]);
    const loading = ref(false);

    window.addEventListener(
      "hashchange",
      () => (view.value = window.location.hash.replace("#", "") || "register")
    );

    onMounted(async () => {
      categories.value = await loadCategoriesMap();
      const keys = Object.keys(categories.value);
      form.category = keys[0] || "";
      subcategories.value = categories.value[form.category] || [];
      form.subcategory = subcategories.value[0] || "";
    });

    const onCategoryChange = () => {
      subcategories.value = categories.value[form.category] || [];
      form.subcategory = subcategories.value[0] || "";
    };

    const onFiles = (e) => (form.files = Array.from(e.target.files || []));

    async function doRegister({ username, email, password }) {
      try {
        await registerUser({ username, email, password });
        alert("Registration successful — please login.");
        window.location.hash = "#/login";
      } catch (e) {
        alert("Register failed: " + e.message);
      }
    }

    async function doLogin({ username, password }) {
      try {
        const data = await login({ username, password });
        localStorage.setItem("role", data.role);
        if (data.role === "ADMIN") {
          alert("Admin logged in!");
          window.location.hash = "#/admin";
        } else {
          alert("Logged in!");
          window.location.hash = "#/complaints";
        }
        await fetchMyComplaints();
      } catch (e) {
        console.error("Register failed:", e);
        alert("Login failed: " + e.message);
      }
    }

    async function doAnonymous() {
      try {
        await anonymous();
        alert("Continuing as guest.");
        window.location.hash = "#/complaints";
        await fetchMyComplaints();
      } catch {
        alert("Anonymous login failed.");
      }
    }

    async function doSubmit() {
      try {
        loading.value = true;
        const data = await submitComplaint(form);
        alert("Complaint submitted (ID=" + data.id + ")");
        Object.assign(form, {
          name: "",
          email: "",
          location: "",
          dateOfIncident: "",
          description: "",
          files: [],
        });
        await fetchMyComplaints();
      } catch (e) {
        alert("Submit failed: " + e.message);
      } finally {
        loading.value = false;
      }
    }

    async function fetchMyComplaints() {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("/api/complaints/my", {
          headers: token ? { Authorization: "Bearer " + token } : {},
        });
        myComplaints.value = res.ok ? await res.json() : [];
      } catch {
        myComplaints.value = [];
      }
    }

    const logout = () => {
      localStorage.removeItem("token");
      myComplaints.value = [];
      window.location.hash = "#/register";
    };

    return {
      view,
      form,
      categories,
      subcategories,
      onCategoryChange,
      onFiles,
      doSubmit,
      doRegister,
      doLogin,
      doAnonymous,
      myComplaints,
      fetchMyComplaints,
      logout,
      loading,
    };
  },
  computed: {
    viewComponent() {
      const v = this.view.replace("/", "") || "register";
      if (v === "login") return "login-view";
      if (v === "register") return "register-view";
      if (v === "admin") return "admin-view";
      if (v === "complaints") return "list-view";
      return "register-view";
    },
  },
  template: `
  <div>
    <nav class="bg-white shadow p-4 flex items-center justify-between">
      <div class="flex items-center space-x-3">
        <div class="text-2xl font-bold text-primary">ResolveIT</div>
        <div class="text-slate-500 text-sm">Report issues — anonymous or signed in</div>
      </div>
      <div class="flex items-center space-x-3">
        <a href="#/register" class="text-slate-600 hover:text-primary">Register</a>
        <a href="#/login" class="text-slate-600 hover:text-primary">Login</a>
        <a href="#/complaints" class="text-slate-600 hover:text-primary">My Complaints</a>
        <button @click="doAnonymous" class="bg-primary text-white px-3 py-1 rounded">Guest</button>
        <button @click="logout" class="text-slate-600">Logout</button>
      </div>
    </nav>
    <div class="max-w-4xl mx-auto p-6">
      <component :is="viewComponent" 
        :form="form"
        :categories="categories"
        :subcategories="subcategories"
        :on-category-change="onCategoryChange"
        :on-files="onFiles"
        :submit-complaint="doSubmit"
        :on-register="doRegister"
        :on-login="doLogin"
        :my-complaints="myComplaints"
        :loading="loading"
      ></component>
    </div>
  </div>`,
};

const RegisterView = {
  props: ["onRegister"],
  setup(props) {
    const username = ref("");
    const email = ref("");
    const password = ref("");
    const doRegister = () => {
      props.onRegister({
        username: username.value,
        email: email.value,
        password: password.value,
      });
    };
    return { username, email, password, doRegister };
  },
  template: `
  <div class="card p-6 bg-white rounded-xl shadow">
    <h2 class="text-xl font-bold mb-4 text-primary">Create an Account</h2>
    <div class="space-y-3">
      <input v-model="username" placeholder="Username" class="input" />
      <input v-model="email" placeholder="Email" class="input" />
      <input v-model="password" type="password" placeholder="Password" class="input" />
      <button @click="doRegister" class="btn-primary w-full bg-primary text-white py-2 rounded hover:bg-green-700">Register</button>
    </div>
  </div>`,
};

const LoginView = {
  props: ["onLogin"],
  setup(props) {
    const username = ref("");
    const password = ref("");
    const doLogin = () =>
      props.onLogin({ username: username.value, password: password.value });
    return { username, password, doLogin };
  },
  template: `
  <div class="card p-6 bg-white rounded-xl shadow">
    <h2 class="text-xl font-bold mb-4 text-primary">Login</h2>
    <div class="space-y-3">
      <input v-model="username" placeholder="Username" class="input" />
      <input v-model="password" type="password" placeholder="Password" class="input" />
      <button @click="doLogin" class="btn-primary w-full bg-primary text-white py-2 rounded hover:bg-green-700">Login</button>
    </div>
  </div>`,
};

const ListView = {
  props: ["myComplaints", "form", "categories", "subcategories", "onCategoryChange", "onFiles", "submitComplaint", "loading"],
  template: `
  <div>
    <h2 class="text-xl font-bold mb-4">Submit New Complaint</h2>
    <div class="card bg-white rounded-xl shadow p-6 mb-6">
      <form @submit.prevent="submitComplaint">
        <div class="grid grid-cols-2 gap-4">
          <div><label>Name</label><input v-model="form.name" placeholder="Your name" class="input" /></div>
          <div><label>Email</label><input v-model="form.email" placeholder="Your email" class="input" /></div>
          <div><label>Category</label><select v-model="form.category" @change="$emit('on-category-change')" class="input"><option v-for="c in Object.keys(categories)" :value="c">{{c}}</option></select></div>
          <div><label>Subcategory</label><select v-model="form.subcategory" class="input"><option v-for="s in subcategories" :value="s">{{s}}</option></select></div>
          <div><label>Location</label><input v-model="form.location" placeholder="Incident location" class="input" /></div>
          <div><label>Date</label><input v-model="form.dateOfIncident" type="date" class="input" /></div>
        </div>
        <div class="mt-3"><label>Description</label><textarea v-model="form.description" rows="4" class="input" placeholder="Describe your issue..."></textarea></div>
        <div class="mt-3 grid grid-cols-2 gap-4">
          <div><label>Urgency</label><select v-model="form.urgency" class="input"><option value="LOW">Low</option><option value="MID">Mid</option><option value="HIGH">High</option></select></div>
          <div><label>Upload Files</label><input type="file" multiple @change="$emit('on-files', $event)" accept=".jpg,.jpeg,.png,.pdf,.mp4" class="input" /></div>
        </div>
        <div class="flex justify-end mt-4">
          <button class="btn-primary bg-primary text-white px-6 py-2 rounded" type="submit">{{ loading ? 'Submitting...' : 'Submit Complaint' }}</button>
        </div>
      </form>
    </div>
    <h2 class="text-xl font-bold mb-3">My Complaints</h2>
    <div v-if="!myComplaints.length" class="card p-4 bg-gray-50">No complaints yet.</div>
    <div v-for="c in myComplaints" :key="c.id" class="card bg-white rounded-xl shadow p-4 mb-3">
      <div class="flex justify-between mb-2">
        <strong>{{c.category}}</strong> — {{c.subcategory}}
        <span :class="{'text-green-600':c.urgency==='LOW','text-yellow-600':c.urgency==='MID','text-red-600':c.urgency==='HIGH'}">{{c.urgency}}</span>
      </div>
      <div>{{c.description}}</div>
      <div class="text-slate-500 text-sm mt-1">Location: {{c.location}} • Date: {{c.dateOfIncident}}</div>
    </div>
  </div>`,
};

const AdminView = {
  data() {
    return {
      complaints: []
    };
  },
  async mounted() {
    const token = localStorage.getItem("token");
    const res = await fetch("/api/admin/complaints", {
      headers: { Authorization: "Bearer " + token }
    });

    this.complaints = res.ok ? await res.json() : [];
  },
  template: `
    <div>
      <h2 class="text-xl font-bold mb-4">Admin Dashboard</h2>
      <div v-if="!complaints.length" class="card p-4 bg-gray-50">No complaints.</div>
      <div v-for="c in complaints" :key="c.id" class="card bg-white rounded-xl shadow p-4 mb-3">
        <div class="flex justify-between mb-2">
          <strong>{{c.category}}</strong> — {{c.subcategory}}
          <span>{{c.urgency}}</span>
        </div>
        <div>{{c.description}}</div>
      </div>
    </div>`
};


createApp(App)
  .component("register-view", RegisterView)
  .component("login-view", LoginView)
  .component("list-view", ListView)
  .component("admin-view", AdminView)
  .mount("#app");

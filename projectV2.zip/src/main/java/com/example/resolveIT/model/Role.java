package com.example.resolveIT.model;

public enum Role {
    USER,
    ADMIN
}

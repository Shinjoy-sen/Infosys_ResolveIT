package com.example.resolveIT;

import com.example.resolveIT.model.Role;
import com.example.resolveIT.model.User;
import com.example.resolveIT.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import jakarta.annotation.PostConstruct;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class ResolveItApplication {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public static void main(String[] args) {
        SpringApplication.run(ResolveItApplication.class, args);
    }
    /*
    @PostConstruct
    public void initAdmin() {
        System.out.println("=== INIT ADMIN CHECK ===");

        var existing = userRepo.findByUsername("admin");
        if (existing.isPresent()) {
            System.out.println("Admin already exists. Skipping creation.");
            return;
        }

        String hash = passwordEncoder.encode("Admin@123");
        User admin = new User("admin", "admin@example.com", hash, Role.ADMIN);
        userRepo.save(admin);

        System.out.println("Admin created with password: Admin@123");
        System.out.println("Hash = " + hash);
    }
        */
}

package com.example.resolveIT.controller;

import com.example.resolveIT.model.Complaint;
import com.example.resolveIT.repo.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:8090")
public class AdminController {

    @Autowired
    private ComplaintRepository complaintRepository;

    @GetMapping("/complaints")
    public List<Complaint> getAllComplaints() {
        // now returns complaints sorted by urgency
        return complaintRepository.findAllSorted();
    }
}

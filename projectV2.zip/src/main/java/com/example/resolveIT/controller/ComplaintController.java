
package com.example.resolveIT.controller;

import com.example.resolveIT.model.Complaint;
import com.example.resolveIT.repo.ComplaintRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/complaints")
@CrossOrigin
public class ComplaintController {

    private final ComplaintRepository repo;
    private final Path uploadDir = Path.of("uploads");

    public ComplaintController(ComplaintRepository repo) throws Exception {
        this.repo = repo;
        if (!Files.exists(uploadDir)) Files.createDirectories(uploadDir);
    }

    @GetMapping("/my")
    public List<Complaint> my(Authentication auth) {
        String user = (auth != null) ? auth.getName() : "anon";
        return repo.findBySubmittedBy(user);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestParam Map<String, String> form,
                                    @RequestParam(value="files", required=false) List<MultipartFile> files,
                                    Authentication auth) throws Exception {
        String user = (auth != null) ? auth.getName() : "anon";
        Complaint c = new Complaint();
        c.setSubmittedBy(user);
        c.setName(form.getOrDefault("name",""));
        c.setEmail(form.getOrDefault("email",""));
        c.setCategory(form.getOrDefault("category",""));
        c.setSubcategory(form.getOrDefault("subcategory",""));
        c.setLocation(form.getOrDefault("location",""));
        String date = form.get("dateOfIncident");
        if (date != null && !date.isBlank()) c.setDateOfIncident(LocalDate.parse(date));
        c.setDescription(form.getOrDefault("description",""));
        c.setUrgency(form.getOrDefault("urgency","LOW"));

        List<String> saved = new ArrayList<>();
        if (files != null) {
            for (MultipartFile f : files) {
                if (f.isEmpty()) continue;
                String fname = System.currentTimeMillis() + "_" + f.getOriginalFilename();
                Files.copy(f.getInputStream(), uploadDir.resolve(fname));
                saved.add(fname);
            }
        }
        c.setAttachments(String.join(",", saved));
        var savedC = repo.save(c);
        return ResponseEntity.ok(Map.of("id", savedC.getId()));
    }
}

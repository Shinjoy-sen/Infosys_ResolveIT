package com.example.resolveIT.repo;

import com.example.resolveIT.model.Complaint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
//import org.springframework.data.repository.CrudRepository;

import java.util.List;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    // Correct field name — Complaint has "submittedBy"
    List<Complaint> findBySubmittedBy(String submittedBy);
    // USER endpoint: fetch logged-in user's complaints
    //List<Complaint> findByUsername(String username);

    // NEW: return all complaints sorted by urgency DESC
    //List<Complaint> findAllByOrderByUrgencyDesc();
    // ADMIN sorted fetch
    @Query(value = """
            SELECT * FROM complaint
            ORDER BY FIELD(urgency, 'HIGH', 'MID', 'LOW')
            """, nativeQuery = true)
    List<Complaint> findAllSorted();
}

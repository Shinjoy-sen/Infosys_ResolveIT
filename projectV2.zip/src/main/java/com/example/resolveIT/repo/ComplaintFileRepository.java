
package com.example.resolveIT.repo;

import com.example.resolveIT.model.ComplaintFile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComplaintFileRepository extends JpaRepository<ComplaintFile, Long> {
}
